# Improved Local Assistant

Local‑first GraphRAG assistant with an offline voice interface. Runs entirely on your machine for privacy, speed, and reliability.

> **⚠️ CI Status**: GitHub Actions workflows are temporarily disabled while we refactor the test suite for better reliability and performance. You can still run workflows manually if needed.

[![CI](https://github.com/hugokos/improved-local-assistant/actions/workflows/ci.yml/badge.svg)](https://github.com/hugokos/improved-local-assistant/actions/workflows/ci.yml)
[![Docs](https://img.shields.io/badge/docs-mkdocs--material-blue)](https://hugokos.github.io/improved-local-assistant/)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](pyproject.toml)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

---

## Overview

**Improved Local Assistant (ILA)** is a production‑oriented, local AI stack that combines a property‑graph knowledge base with hybrid retrieval (graph + vector + BM25) and a voice‑first interface (offline STT/TTS). It’s designed for edge hardware and developer workstations where privacy and low latency matter.

**Highlights**

* **Local‑first privacy:** all inference, retrieval, and voice processing run on your device.
* **Deeper answers:** GraphRAG routing over a property graph preserves semantics and relationships.
* **Voice‑native:** Vosk (STT) + Piper (TTS) for hands‑free chat with streaming responses.
* **Flexible:** Web UI, REST & WebSocket APIs, and CLI tools; configurable models via Ollama.

---

## Architecture

A high-level look at how the pieces fit together:

```mermaid
flowchart LR

  %% Client Layer
  subgraph Client
    UI[Web UI / CLI]
    STT[Vosk STT]
    TTS[Piper TTS]
  end

  %% API + Routing Layer
  subgraph API_Layer
    API_API[FastAPI REST & WebSocket]
    Router[Semantic Router]
    Ranker[Context Builder]
  end

  %% Index Layer
  subgraph Indexes
    KGPrime[KG-Prime]
    KGLive[KG-Live]
    VDB[Vector Index]
    BM25[BM25 Index]
  end

  %% Model
  LLM[Local LLM via Ollama]

  %% Ingestion
  subgraph Ingestion
    DOCS[Source Docs]
    CHUNK[Chunker]
    EXTRACT[Entity/Relation Extraction]
    TRIPLES[Triple Generator]
  end

  %% Voice flow
  UI -->|Audio| STT -->|Text| API_API
  API_API -->|Text| TTS -->|Audio| UI

  %% Chat flow
  UI --> API_API --> Router
  Router --> KGPrime
  Router --> KGLive
  Router --> VDB
  Router --> BM25
  Router --> Ranker -->|Cited Context| LLM --> API_API

  %% Ingestion flow
  DOCS --> CHUNK --> EXTRACT --> TRIPLES --> KGPrime
  EXTRACT --> KGLive
  TRIPLES --> VDB
```

### Key components (what’s innovative and why it matters)

- **Dual graph design (KG-Prime + KG-Live):** Ship a prebuilt, domain-specific property graph (KG-Prime) and grow a live conversational graph (KG-Live) on the fly. This preserves long-term memory without ballooning the LLM context window, and it lets you learn from user interactions safely and locally.

- **Semantic Router (graph + vector + keyword):** Every query is routed across three complementary signals: graph traversal to follow relationships and constraints; vector search to capture semantic similarity; and BM25 to guarantee exact-term recall (IDs, commands, names). The router selects only the minimal subgraph/passages needed, which cuts prompt size and improves relevance.

- **Ranking & Context Builder (cited snippets):** Retrieved candidates are re-ranked and assembled into a small, cited context. This keeps the LLM focused, improves faithfulness, and makes responses auditable.

- **All-offline voice loop (Vosk + Piper):** Speech-to-text (Vosk) streams partial and final transcripts; Piper TTS streams audio output as tokens arrive from the LLM—so you get near-instant feedback without any cloud calls.

- **Model-agnostic via Ollama:** Swap models per task (e.g., faster small model for chat, larger one for synthesis) without changing the rest of the stack. Local execution preserves privacy and reduces latency.

- **Ingestion pipeline built for graphs:** Chunking → entity/relation extraction → triple generation feeds both the property graph and the vector index. This ensures structure (for reasoning) and semantics (for recall) stay in sync.

---

## Getting Started

### Prerequisites

* **Supported OS**: Windows 10/11 and Linux (Ubuntu 20.04+)
* **Python**: 3.10–3.12 (aligns with NetworkX 3.4.x's support window)
* **Git**
* **Ollama** (running locally)
* Optional: **CUDA‑capable GPU** for models that can use it

> **Note**: macOS is not supported due to voice processing dependencies.

### Quick Start

```bash
# Clone and setup
git clone https://github.com/hugokos/improved-local-assistant.git
cd improved-local-assistant

# Install (requires Python 3.10+)
pip install -r requirements.txt
pip install -e . -c constraints.txt

# Run
ila api --reload
```

**Windows users**: See [installation guide](docs/installation.md) for detailed setup.

**Migrating**: `python run_app.py` → `ila api`

**Access the Application:**

* **Web UI**: [http://localhost:8000](http://localhost:8000)
* **API docs**: [http://localhost:8000/docs](http://localhost:8000/docs) (OpenAPI/Swagger)
* **Health check**: [http://localhost:8000/api/health](http://localhost:8000/api/health)

**CLI Commands:**

```bash
# Start the API server
ila api                    # Production mode
ila api --reload           # Development mode with auto-reload
ila api --port 8080        # Custom port

# Interactive GraphRAG REPL
ila repl

# System utilities
ila health                 # Check system health
ila download-graphs all    # Download prebuilt graphs
ila bench                  # Run benchmarks

# Get help
ila --help
```

---

## Configuration

ILA uses a flexible configuration system with config files and environment variables:

### Config Files

```bash
# Use default configuration
ila api

# Use development config (faster models, debug mode)
ila api --config configs/dev.yaml

# Use custom configuration
export ILA_CONFIG="configs/my-config.yaml"
ila api
```

### Environment Variables

```bash
# Ollama settings
export ILA_OLLAMA_HOST="http://127.0.0.1:11434"
export ILA_MODEL_CHAT="hermes3:3b"          # chat/inference model
export ILA_MODEL_EMBED="nomic-embed-text"   # embedding model

# Server settings
export ILA_HOST="0.0.0.0"
export ILA_PORT=8000

# Storage paths
export ILA_DATA_DIR="./data"                 # stores graphs, caches, logs
export ILA_PREBUILT_DIR="./data/prebuilt_graphs"

# Retrieval weights (tune to your preference)
export ILA_USE_GRAPH=true
export ILA_USE_VECTOR=true
export ILA_USE_BM25=true
export ILA_ROUTER_GRAPH_WEIGHT=0.5
export ILA_ROUTER_VECTOR_WEIGHT=0.4
export ILA_ROUTER_BM25_WEIGHT=0.1
```

> **Tip**: Create a `.env` file in the project root with your settings, or copy and modify `configs/dev.yaml`.

---

## Retrieval & Routing

* **Graph traversal** finds semantically linked entities and relations.
* **Vector search** (embedding‑based) surfaces semantically similar passages.
* **BM25** ensures exact‑term recall for names, commands, and IDs.
* The **router** balances these signals and builds a small, cited context for the LLM.

To tweak behavior, adjust the `ILA_USE_*` flags and weights, or the per‑retriever limits (k‑values) in your config.

---

## Voice Interface (Offline)

* **STT (Vosk):** per‑session recognizers; real‑time partial and final transcripts; VAD‑assisted utterance boundaries.
* **TTS (Piper):** streaming synthesis; configurable voices; audio chunks are sent to the UI while tokens stream from the LLM.

**Enable voice in the Web UI:** toggle the mic orb to start/stop listening. Configure default devices in your browser/OS.

---

## APIs & Examples

The server exposes a REST API and a WebSocket for streaming.

**Health**

```bash
curl http://localhost:8000/api/health
```

**Chat (REST)**

```bash
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Hello!"}]}'
```

**Streaming (WebSocket) — Python snippet**

```python
import asyncio, websockets, json

async def main():
    async with websockets.connect("ws://localhost:8000/ws") as ws:
        await ws.send(json.dumps({"type": "user", "content": "Explain GraphRAG in 2 lines"}))
        async for msg in ws:
            print(msg)

asyncio.run(main())
```

---

## Performance & Tuning

* **Model choice:** prefer smaller quantized models for low TTFT; switch to larger models for depth.
* **Caching:** enable embedding/result caches to speed repeated queries.
* **Concurrency:** limit concurrent sessions on low‑power systems; configure worker pool size.
* **Retrieval budgets:** cap per‑retriever `k` and token budgets to avoid oversized contexts.

### Benchmarks (reproducible)

Use the included tools to measure **TTFT**, **tokens/s**, and **end‑to‑end latency**:

```bash
# Quick benchmark via CLI
ila bench

# Detailed benchmarking scripts
python scripts/run_benchmarks.py
python scripts/benchmark_models.py --model hermes3:3b --contexts 1024 2048 4096 --runs 5

# Using Makefile
make test-smoke    # Quick smoke tests
```

Results are stored under `benchmarks/` with CSV/JSON outputs you can plot.

---

## Security & Privacy

* No external API calls are required; network calls can be disabled entirely.
* Logs and caches stay in `ILA_DATA_DIR` on your machine.
* Sanitization hooks are available before content is persisted to the graph.

---

## Troubleshooting

* **Ollama not reachable** → verify `OLLAMA_HOST` and that the daemon is running.
* **Model not found** → `ollama pull <name>` again; confirm tags.
* **Mic or TTS silent** → check OS device permissions and your browser’s site settings.
* **Port in use** → change `ILA_PORT` or free the port.

---

## Roadmap (selected)

* Presets for **speed vs. quality** routing and model bundles.
* Optional Windows/macOS packaged launchers.
* Coverage reporting and Codecov badge in CI.
* Additional docs: developer internals, deployment patterns, and advanced voice controls.

---


## Contributing

We welcome issues and PRs! Please read:

* [CONTRIBUTING.md](CONTRIBUTING.md)
* [CODE\_OF\_CONDUCT.md](CODE_OF_CONDUCT.md)

Use conventional commits when possible (`feat:`, `fix:`, `docs:` …).

### Local "Preflight CI"

Run these checks before pushing to catch issues early:

```bash
# Setup dev environment
python -m venv .venv && .venv\Scripts\activate  # Windows
# python -m venv .venv && source .venv/bin/activate  # Linux
python -m pip install -U pip
pip install -r requirements.txt
pip install -e . -c constraints.txt
pip install pytest-cov

# Dependency health check
python -m pip check
pip install -U pipdeptree
pipdeptree --warn fail -p llama-index,llama-index-core,llama-index-embeddings-ollama

# Lint + type checks
pre-commit run --all-files
ruff check .
black --check .
mypy src

# Tests (with coverage)
pytest --help | grep -- --cov  # sanity check
pytest -q -vv -ra --cov=improved_local_assistant --cov-report=xml --fail-under=70
```

**Run dev server**: `ila api --reload` (on Windows, ensure venv is active; `.\.venv\Scripts\ila.exe` works too).
**Docs preview**: `mkdocs serve`

---

## License

MIT — see [LICENSE](LICENSE).

## Acknowledgments

Thanks to the maintainers of **Ollama**, **LlamaIndex**, **FastAPI**, **Vosk**, and **Piper** for foundational tooling.

<!-- Optional demo: place a short GIF at docs/assets/demo.gif and uncomment below -->

<!-- ![Demo](docs/assets/demo.gif) -->
