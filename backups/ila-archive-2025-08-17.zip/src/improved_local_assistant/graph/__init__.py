"""
Graph management and knowledge graph operations.
"""
