"""
API routes for Improved Local Assistant.
"""
