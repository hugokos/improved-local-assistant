"""
FastAPI application and routes.
"""
