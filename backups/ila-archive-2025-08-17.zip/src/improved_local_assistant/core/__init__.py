"""
Core utilities, settings, and shared components.
"""
