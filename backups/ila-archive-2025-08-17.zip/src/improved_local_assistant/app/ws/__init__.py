"""WebSocket endpoints for the Improved Local AI Assistant."""

# This file will be populated with WebSocket endpoint imports
