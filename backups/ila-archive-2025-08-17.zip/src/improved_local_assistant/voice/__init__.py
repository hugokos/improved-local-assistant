"""
Voice interface components: TTS, STT, and voice management.
"""
