"""
Hybrid retrieval system with graph, vector, and BM25 components.
"""
