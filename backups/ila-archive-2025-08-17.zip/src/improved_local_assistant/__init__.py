"""Improved Local AI Assistant.

A production-ready local AI assistant with GraphRAG technology and voice interface.
"""

__version__ = "1.0.0"
__author__ = "AI Team"
__email__ = "team@example.com"

"""Improved Local AI Assistant.

A production-ready local AI assistant with GraphRAG technology and voice interface.
"""

__version__ = "1.0.0"
__author__ = "AI Team"
__email__ = "team@example.com"

__all__ = ["app"]
